# Enj Manager Post Command lambda Python 
# Adam Phelps 7/6/2020